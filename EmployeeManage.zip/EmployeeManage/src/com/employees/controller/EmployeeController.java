package com.employees.controller;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.employees.pojo.Employee;
import com.employees.pojo.Status;
import com.employees.service.EmployeeService;



@Controller
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeservice;
	
	
	@RequestMapping(value="/loginpage",method=RequestMethod.GET)
	public String loginEmployee(Model model)
	{
		System.out.println("inside login page.");
		model.addAttribute("loginpage","WELCOME TO LOGIN PAGE");
		return "login";
	}
	
	@RequestMapping(value="/afterloginpage",method=RequestMethod.POST)
	public String afterLoginPage(@RequestParam("username") String userName,@RequestParam("password") String passWord,Model model,HttpSession session)
	{
		System.out.println("inside after login form.");
		
		if("manager".equalsIgnoreCase(userName) && "1234".equalsIgnoreCase(passWord))
   	 {
   		 System.out.println("inside admin page");
   		 model.addAttribute("adminsuccess","WELCOME TO MANAGER");
   		 session.setAttribute("manager", userName);
   		 return "Adminwelcome";
        }
   	 else
   	 {
   		 Employee emp1=this.employeeservice.loginPage(userName, passWord);
   		 if(emp1!=null)
   		 {
   			 System.out.println("inside user login page.");
   			 String name=emp1.getEmpname();
   			 System.out.println("print name:" + name);
   			 String s="WELCOME TO MR." + name;
   			System.out.println("print name:" + name);
   			 model.addAttribute("empname"+s);
   			 session.setAttribute("employee",emp1);    
   			 return "employee";
   		 }
   		 else
   		 {
   			
   			 System.out.println("inside invalid page.");
   			 model.addAttribute("errormessage","Invalid credentials.");
   			 return "login";
   		 }
       }
   	
		
	}
	
	@RequestMapping(value="/getregistration",method=RequestMethod.GET)
	public String getRegistrationuserPage(Model model)
	{	
		System.out.println("inside registration page.");
		Employee emp=new Employee();
		model.addAttribute("emp",emp);
		return "registration";
	}
	
	@RequestMapping(value="/afterregistration",method=RequestMethod.POST)
	public String afterRegistration(@ModelAttribute("emp") Employee emp,Model model)
	{
		System.out.println("inside afterregistration controller.");
		boolean bool=this.employeeservice.addEmployee(emp);
		if(bool==true)
		{
			System.out.println("success.");
			model.addAttribute("registrationsuccessfully","Employee record is successfully entered.");
			return "Adminwelcome";
		}
		else
		{
			System.out.println("failure.");
			model.addAttribute("registrationfailed","Employee record is not entered.");
			return "Adminwelcome";
		}
		
	}
	
	@RequestMapping(value="/getallemployeerecord",method=RequestMethod.GET)
	public String fetchAllEmployee(Model model)
	{
		System.out.println("inside fetch controller");
		List<Employee>list=this.employeeservice.listEmployees();
		if(list!=null)
		{
			System.out.println("Employee record is successfully fetched.");
			model.addAttribute("successmessage","Employee record is fetched");
			model.addAttribute("list",list);
			System.out.println("size:" + list.size());
			return "Adminwelcome";
		}
		else
		{
			model.addAttribute("failuremessage","Employee record is empty");
			return "Adminwelcome";
		}
		
	}
	
	@RequestMapping(value="/updaterecord",method=RequestMethod.GET)
	public String updateRecord(Model model,@RequestParam("empid") Integer empid)
	{
		System.out.println("inside update record."+ empid);
		Employee emp=this.employeeservice.getEmployeeById(empid);
		model.addAttribute("employee",emp);
		Employee emp1=new Employee();
		model.addAttribute("emp",emp1);
		return "Adminwelcome";
	}
	
	@RequestMapping(value="/updatingrecord",method=RequestMethod.POST)
	public String afterUpadteRecord(@ModelAttribute("emp") Employee emp,Model model)
	{
		System.out.println("inside after update controller.");
		int number=this.employeeservice.updateEmployee(emp);
		System.out.println("number:" + number);
		if(number==1)
		{
			model.addAttribute("successupdate","Employee Record is updated.");
			return "Adminwelcome";
		}
		else
		{
			model.addAttribute("failureupdate","Employee record is not present.");
			return "Adminwelcome";
		}
		
	}
	
	
	@RequestMapping(value="/deleterecord",method=RequestMethod.GET)
	public String deletetRecord(@RequestParam("empid") Integer empid,Model model)
	{
		System.out.println("inside delete controller.");
		boolean bool=this.employeeservice.removeEmployee(empid);
		if(bool==true)
		{
			model.addAttribute("deleterecord","Employee record is deleted.");
			return "Adminwelcome";
		}
		else
		{
			model.addAttribute("failure","Employee record is not found.");
			return "Adminwelcome";
		}
		
	}
	
	@RequestMapping(value="/statusupdate",method=RequestMethod.GET)
	public String getEmployeeStatus(Model model)
	{
		System.out.println("inside employee status.");
		model.addAttribute("message1","inside status form page.");
		return "employee";
	}
	
	@RequestMapping(value="/statusupdating",method=RequestMethod.POST)
	public String afterGettingStatus(@RequestParam("empstatus") String empstatus,Model model,HttpSession session)
	{
		System.out.println("inside status page" + empstatus);
		Date date=Calendar.getInstance().getTime();
		System.out.println("time:"+ date);
		
		Employee employee=(Employee)session.getAttribute("employee");
		System.out.println(employee);
		System.out.println("print :"+ employee.getEmpid());
		Status status=new Status();
		status.setEmployee(employee);
		status.setEmpstatus(empstatus);
		status.setDate(date);
		boolean bool=this.employeeservice.fillStatus(status);
		if(bool==true)
		{
		model.addAttribute("successful", "status is successfully added.");
		return "employee";
		}
		else
		{
			model.addAttribute("failuremessage", "status is not saved.");
			return "employee";
		}
		
	}
	
	@RequestMapping(value="/adminlogout",method=RequestMethod.GET)
	public String logout(Model model,HttpSession session)
	{
		System.out.println("inside logout button.");
		String name=(String)session.getAttribute("manager");
		System.out.println("manager name:" + name);
		session.invalidate();
		return "index";
	}
	
	@RequestMapping(value="/employeelogout",method=RequestMethod.GET)
	public String employeeLogout(Model model,HttpSession session)
	{
		System.out.println("inside employee logout.");
		Employee emp=(Employee)session.getAttribute("employee");
		System.out.println("name:"+ emp.getEmpname());
		session.invalidate();
		return "index";
	}

	@RequestMapping(value="/changepassword",method=RequestMethod.GET)
	public String changePassword(Model model)
	{
		System.out.println("inside change password.");
		model.addAttribute("changepassword","YOU CAN CHANGE YOUR PASSWORD.");
	    return "login";	
	}
	
	@RequestMapping(value="/afterchangepassword",method=RequestMethod.POST)
	public String afterChangePassword(@RequestParam("newpassword") String password,@RequestParam("perviouspassword") String perviouspassword,Model model)
	{
		System.out.println("inside changing password.");
		System.out.println("new password:"+ password);
		boolean bool1=this.employeeservice.changePassword(password, perviouspassword);
		if(bool1==true)
		{
			model.addAttribute("successchange","YOUR PASSWORD IS SUCCESSFULLY CHANGE.");
			return "login";
         }
		else
		{
			model.addAttribute("failurechange","YOUR PASSWORD IS NOT CHANGED.");
			return "login";
		}
	}
	
	@RequestMapping(value="/employeeownstatus",method=RequestMethod.GET)
	public String getEmployeeOwnRecord(Model model,HttpSession session)
	{
		System.out.println("inside getemployeereord.");
		Employee employee1=(Employee)session.getAttribute("employee");
		System.out.println("id:"+ employee1.getEmpid());
		String s=employee1.getEmpname();
		s=s.toUpperCase();
		List<Status>list=this.employeeservice.getEmployeeStatus(employee1.getEmpid());
		if(list!=null)
		{
			System.out.println("inside employeestatus.....");
			model.addAttribute("successfetch","LIST OF STATUS OF EMPLOYEE "+ s);
			model.addAttribute("list", list);
			return "employee";
		}
		else
		{
			System.out.println("inside failurestatus...");
			model.addAttribute("failurefetch","List of status fetch is not avilable.");
			return "employee";
		}
	}
	
	@RequestMapping(value="/updatestatus",method=RequestMethod.GET)
	public String editStatus(@RequestParam("statusid") Integer statusid,Model model)
	{
		System.out.println("status id:"+ statusid);
		Status status=this.employeeservice.updateStatus(statusid);
		if(status!=null)
		{
			System.out.println("successfully done.");
			model.addAttribute("successstatus","YOU CAN UPDATE THE STATUS.");
			Date date=Calendar.getInstance().getTime();
			model.addAttribute("date", date);
			model.addAttribute("status2",status);
			Status status1=new Status();
			model.addAttribute("status",status1);
			System.out.println("successfully done1.");
			return "employee";
		}
		else
		{
			System.out.println("id is not found.");
			model.addAttribute("failure","STATUS ID IS NOT FOUND.");
			return "employee";
		}
		
	}
	
	@RequestMapping(value="/afterstatus",method=RequestMethod.POST)
	public String gotUpdate(@ModelAttribute("status") Status staus,Model model)
	{
		System.out.println("status id:"+ staus.getStatusid());
		Integer i=this.employeeservice.updateStatus(staus);
		System.out.println("print:"+ i);
		if(i==1)
		{
			model.addAttribute("successupdated","STATUS IS SUCCESSFULL UPDATED.");
			return "employee";
		}
		else
		{
			model.addAttribute("failureupdated","STATUS IS NOT UPDATED.");
			return "employee";
		}
	}
}
