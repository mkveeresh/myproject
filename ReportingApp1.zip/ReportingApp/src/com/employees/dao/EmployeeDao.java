package com.employees.dao;

import java.util.List;



import com.employees.pojo.Employee;
import com.employees.pojo.Status;



public interface EmployeeDao {
	
public boolean addEmployee(Employee employee);
	
	public int updateEmployee(Employee employee);
	public Employee getEmployeeById(int id);
	public boolean removeEmployee(int id);
	public List<Employee> listEmployees();
	public Employee loginPage(String username,String password);
	public boolean fillStatus(Status status);
	public boolean changePassword(String password,String perviouspassword);
	public List<Status>getEmployeeStatus(int empid);
	public Status updateStatus(int id);
	public int updateStatus(Status status);
	public List<Status>listStatus();

}
