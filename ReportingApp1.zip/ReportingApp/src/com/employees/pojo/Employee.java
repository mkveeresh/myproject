package com.employees.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Size;

@Entity
@Table(name="EmployeeManagers")
public class Employee  {

	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empname=" + empname
				+ ", empmobile=" + empmobile + ", empusername=" + empusername
				+ ", emppassword=" + emppassword + "]";
	}

	private int empid;
	private String empname;
	private String empmobile;
	private String empusername;
	private String emppassword;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO,generator="EMPLOYEEMANAGERS_SEQ")
	@SequenceGenerator(name="EMPLOYEEMANAGERS_SEQ",allocationSize=1,sequenceName="EMPLOYEEMANAGERS_SEQ")
	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	@Column(name = "employeename")
	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	@Column(name = "employeemobileno")
	
	public String getEmpmobile() {
		return empmobile;
	}

	public void setEmpmobile(String empmobile) {
		this.empmobile = empmobile;
	}

	@Column(name = "employeeusername")
	
	public String getEmpusername() {
		return empusername;
	}

	public void setEmpusername(String empusername) {
		this.empusername = empusername;
	}

	@Column(name = "employeepassword")
	
	public String getEmppassword() {
		return emppassword;
	}

	public void setEmppassword(String emppassword) {
		this.emppassword = emppassword;
	}

	

}
