package com.employees.daointer;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.employees.dao.EmployeeDao;
import com.employees.pojo.Employee;
import com.employees.pojo.Status;


@Repository
@Transactional
public class EmployeedaoInter implements EmployeeDao {
	
	@Autowired
	@PersistenceContext
	private EntityManager entitymanager ;


	
	@Override
	public Employee loginPage(String username, String password) {
		
		System.out.println("inside login dao layer.");
		 Employee employee=null;
		 try{
		String str="select e from Employee e where e.empusername=:userName and e.emppassword=:password";
		Query query=this.entitymanager.createQuery(str);
		employee=(Employee)query.setParameter("userName",username).setParameter("password",password).getSingleResult();
		 }
		 catch(Exception ex)
		 {
			 System.out.println("message:" + ex.getMessage());
		 }
		return employee;
		
	}

	@Override
	public boolean addEmployee(Employee employee) {
		System.out.println("inside registration dao.");
		if(employee!=null)
		{
		this.entitymanager.persist(employee);
		this.entitymanager.flush();
		return true;
		}
		else
			return false;
		
	}

	@Override
	public int updateEmployee(Employee employee) {
		System.out.println("inside update record dao." + employee.getEmpname());
		this.entitymanager.merge(employee);
		this.entitymanager.flush();
		return employee.getEmpid();
		
	}

	@Override
	public Employee getEmployeeById(int id) {
		System.out.println("inside getemployee dao.");
		String str="select e from Employee e where e.empid=:empid";
		Query query=this.entitymanager.createQuery(str);
		Employee emp=(Employee)query.setParameter("empid",id).getSingleResult();
		return emp;
	}

	@Override
	public boolean removeEmployee(int id) {
		System.out.println("inside delete operation.");
		String deletestring="delete from Employee e where e.empid=:id";
		Query query=this.entitymanager.createQuery(deletestring);
		int result=query.setParameter("id",id).executeUpdate();
		if(result>0)
		return true;
		else
			return false;
		
	}

	@Override
	public List<Employee> listEmployees() {
		System.out.println("inside list dao.");
		String str1="select e from Employee e";
		   Query query=this.entitymanager.createQuery(str1);
		   List<Employee> list=query.getResultList();
		   return list;
	}

	@Override
	public boolean fillStatus(Status status) {
		System.out.println("inside fillstatus list.");
		System.out.println(status.toString());
		this.entitymanager.persist(status);
		this.entitymanager.flush();
		return true;
	}

	@Override
	public boolean changePassword(String password,String perviouspassword) {
		System.out.println("inside change password dao.");
		String changepassword="update Employee e set e.emppassword=:password where e.emppassword=:perviouspassword";
		Query query=this.entitymanager.createQuery(changepassword);
		query.setParameter("password",password).setParameter("perviouspassword",perviouspassword);
		int result=query.executeUpdate();
		if(result>0)
		return true;
		else
			return false;
	}

	@Override
	public List<Status> getEmployeeStatus(int empid) {
		System.out.println("inside employee dao.");
		
		String fetchquery="select u from Status u where u.employee.empid=:id";
		Query fetch=this.entitymanager.createQuery(fetchquery).setParameter("id",empid);
		List<Status> list=fetch.getResultList();
		return list;
	}
	@Override
	public Status updateStatus(int id) {
		System.out.println("inside updatestatus."+ id);
		String updatestatusid="select o from Status o where o.statusid=:id";
		Query query=this.entitymanager.createQuery(updatestatusid).setParameter("id",id);
		Status staus=(Status)query.getSingleResult();
		return staus;
	}

	@Override
	public int updateStatus(Status status) {
		System.out.println("inside update staus dao." + status.getStatusid());
		this.entitymanager.merge(status);
		this.entitymanager.flush();
		return status.getStatusid();
		
	}

	@Override
	public List<Status> listStatus() {
		
		System.out.println("inside fetch status.");
		String fetchstatus="select s from Status s";
		List<Status> list=this.entitymanager.createQuery(fetchstatus).getResultList();
		return list;
	}

	

	
}
