package com.employees.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.ui.Model;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.employees.pojo.Status;

public class StatusExcelView extends AbstractExcelView{

	@Override
	protected void buildExcelDocument(Map<String, Object> model,
			HSSFWorkbook workbook, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		      List<Status> list2=(List<Status>)model.get("statusList");
		     System.out.println("size:" + list2.size());
          Sheet sheet=workbook.createSheet("EMPLOYEE STATUS LIST");

              Row row=sheet.createRow(0);
               row.createCell(0).setCellValue("STATUS ID");
               row.createCell(1).setCellValue("EMP SATUS");
               row.createCell(2).setCellValue("STATUS DATE");

                int rownum=1;
                
               for (Status status : list2) {
            	   
            	   HSSFRow row1 = (HSSFRow)sheet.createRow(rownum++);
            	   row1.createCell(0).setCellValue(status.getStatusid());
                   row1.createCell(1).setCellValue(status.getEmpstatus());
                   row1.createCell(2).setCellValue(status.getDate().toString());
				
			}
               
	}

	
		
	     
	     
	

	
		
		
	

}
